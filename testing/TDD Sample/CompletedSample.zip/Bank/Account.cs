﻿using System;

namespace Bank
{
    public class Account
    {
        private readonly ITransactionLog _transactionLog;

        public Account(ITransactionLog transactionLog)
        {
            Id = Guid.NewGuid();
            this._transactionLog = transactionLog;
        }

        public Account(ITransactionLog transactionLog, int initialDeposit)
            : this(transactionLog)
        {
            Balance = initialDeposit;
        }

        public int Balance { get; set; }

        public Guid Id { get; set; }

        public void Deposit(int deposit)
        {
            Balance += deposit;
        }

        public void Withdraw(int withdrawal)
        {
            if (Balance < withdrawal)
            {
                throw new ApplicationException("Insufficient funds");
            }

            Balance -= withdrawal;
        }

        public Transaction Transfer(Account a2, int amount)
        {
            Withdraw(amount);
            a2.Deposit(amount);

            return _transactionLog.AddTransactionToLog(Id, a2.Id, amount);
        }
    }
}
