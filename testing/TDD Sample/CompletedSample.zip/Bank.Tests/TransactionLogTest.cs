﻿using System;
using System.Linq;

using NUnit.Framework;

namespace Bank.Tests
{
    [TestFixture]
    public class TransactionLogTest
    {
        [Test(Description = "Transaction log is empty on creation")]
        public void EmtpyLogOnCreationTest()
        {
            var log = new TransactionLog();
            Assert.IsEmpty(log.Transactions);
        }

        [Test(Description = "Transaction log contains added transaction")]
        public void TransactionAddedToLogTest()
        {
            var log = new TransactionLog();
            var a1 = Guid.NewGuid();
            var a2 = Guid.NewGuid();
            var transaction = log.AddTransactionToLog(a1, a2, 100);
            Assert.IsNotNull(transaction);

            Assert.Contains(transaction, log.Transactions.ToList());
        }
    }
}
