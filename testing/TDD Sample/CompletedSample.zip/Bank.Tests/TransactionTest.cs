﻿using System;

using Microsoft.QualityTools.Testing.Fakes;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Bank.Tests
{
    [TestClass]
    public class TransactionTest
    {
        [TestMethod]
        public void CreateTransactionTest()
        {
            // Shims can be used only in a ShimsContext:
            using (ShimsContext.Create())
            {
                // Arrange
                var a1 = Guid.NewGuid();
                var a2 = Guid.NewGuid();
                const int Amount = 100;

                var now = new DateTime(2015, 1, 1);

                System.Fakes.ShimDateTime.NowGet = () => now;

                // Instantiate the component under test:
                // Act
                var transaction = new Transaction(a1, a2, Amount);

                // Assert
                Assert.AreEqual(a1, transaction.AccountFrom);
                Assert.AreEqual(a2, transaction.AccountTo);
                Assert.AreEqual(Amount, transaction.Amount);
                Assert.AreEqual(now, transaction.Timestamp);
            }
        }
    }
}
