﻿using Moq;
using NUnit.Framework;
using System;

namespace Bank.Tests
{
    [TestFixture]
    public class AccountTest
    {
        private Mock<ITransactionLog> _mockLog;

        /// <summary>
        /// Executed before other tests
        /// </summary>
        [TestFixtureSetUp]
        public void TestFixtureSetUp()
        {
        }

        /// <summary>
        /// Executed after all the other tests
        /// </summary>
        [TestFixtureTearDown]
        public void TestFixtureTearDown()
        {
        }

        /// <summary>
        /// Executed before each test
        /// </summary>
        [SetUp]
        public void SetUp()
        {
            _mockLog = new Mock<ITransactionLog>();
        }

        /// <summary>
        /// Executed after each test
        /// </summary>
        [TearDown]
        public void TearDown()
        {
            _mockLog = null;
        }

        [Test(Description = "The account should have an ID after opening.")]
        public void NewAccountIdTest()
        {
            var account = new Account(_mockLog.Object);
            Assert.AreNotEqual(Guid.Empty, account.Id);
        }

        [Test(Description = "The account balance should be zero after opening.")]
        public void NewAccountBalanceTest()
        {
            var account = new Account(_mockLog.Object);
            Assert.AreEqual(0, account.Balance);
        }

        [Test(Description = "The account should have an ID after opening with initial deposit.")]
        public void NewAccountWithDepositIdTest([Values(100, 200, 300)] int initialDeposit)
        {
            var account = new Account(_mockLog.Object, initialDeposit);
            Assert.AreNotEqual(Guid.Empty, account.Id);
        }

        [Test(Description = "The account balance should be equal to initial deposit.")]
        public void NewAccountWithDepositBalanceTest([Values(100, 200, 300)] int initialDeposit)
        {
            var account = new Account(_mockLog.Object, initialDeposit);
            Assert.AreEqual(initialDeposit, account.Balance);
        }

        [Test(Description = "The account balance should be increased by deposit amount.")]
        public void DepositAfterCreationWithInitialBalanceTest([Values(100, 200, 300)] int deposit)
        {
            const int InitialDeposit = 100;
            var account = new Account(_mockLog.Object, InitialDeposit);
            var balanceBeforeDeposit = account.Balance;
            account.Deposit(deposit);
            Assert.AreEqual(balanceBeforeDeposit + deposit, account.Balance);
        }

        [Test(Description = "The account balance should be decreased by withdrawal amount.")]
        public void WithdrawalTest()
        {
            const int Withdrawal = 200;
            const int Initial = 300;
            var account = new Account(_mockLog.Object, Initial);
            account.Withdraw(Withdrawal);
            Assert.AreEqual(Initial - Withdrawal, account.Balance);
        }

        [Test(Description = "The withdrawal should not be allowed if there is not enough funds.")]
        public void WithdrawalNotAllowedTest()
        {
            const int Withdrawal = 300;
            const int Initial = 200;
            var account = new Account(_mockLog.Object, Initial);
            Assert.Throws<ApplicationException>(() => account.Withdraw(Withdrawal));
            Assert.AreEqual(Initial, account.Balance);
        }

        [Test(Description = "The exception message should be 'Insufficient funds' if withdrawal is attempted when there is not enough funds.")]
        public void WithdrawalNotAllowedMessageTest()
        {
            const int Withdrawal = 300;
            const int Initial = 200;
            var account = new Account(_mockLog.Object, Initial);
            var ex = Assert.Throws<ApplicationException>(() => account.Withdraw(Withdrawal));
            Assert.AreEqual("Insufficient funds", ex.Message);
        }

        [Test(Description = "The account balance should be decreased by amount which is transfered to another account.")]
        public void FirstAccountBalanceAfterTransferTest()
        {
            _mockLog.Setup(x => x.AddTransactionToLog(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<int>())).Returns((Transaction)null);
            var a1 = new Account(_mockLog.Object, 500);
            var a2 = new Account(_mockLog.Object, 100);
            const int Amount = 150;
            a1.Transfer(a2, Amount);
            Assert.AreEqual(350, a1.Balance);
        }

        [Test(Description = "The account balance should be increased by amount which is transfered from another account.")]
        public void SecondAccountBalanceAfterTransferTest()
        {
            _mockLog.Setup(x => x.AddTransactionToLog(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<int>())).Returns<Transaction>(null);
            var a1 = new Account(_mockLog.Object, 500);
            var a2 = new Account(_mockLog.Object, 100);
            const int Amount = 150;
            a1.Transfer(a2, Amount);
            Assert.AreEqual(250, a2.Balance);
        }

        [Test(Description = "Transfer should not be allowed when there is not enough funds.")]
        public void TransferNotAllowedTest()
        {
            var a1 = new Account(_mockLog.Object, 100);
            var a2 = new Account(_mockLog.Object, 100);
            const int Amount = 150;
            Assert.Throws<ApplicationException>(() => a1.Transfer(a2, Amount));
            Assert.AreEqual(100, a1.Balance);
        }

        [Test(Description = "Transfer creates a transaction which is added to log")]
        public void TransactionAddedToLogTest()
        {
            var account1 = new Account(_mockLog.Object, 200);
            var account2 = new Account(_mockLog.Object, 0);

            var expectedTransaction = new Transaction(account1.Id, account2.Id, 100);

            _mockLog.Setup(x => x.AddTransactionToLog(It.IsAny<Guid>(), It.IsAny<Guid>(), It.IsAny<int>())).Returns(expectedTransaction);
            var transaction = account1.Transfer(account2, 100);

            Assert.AreEqual(expectedTransaction, transaction);
        }
    }
}
